z/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.login;


/**
 *
 * @author sebas
 */
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;


public class  NuevaVentana extends JFrame implements ActionListener  {
    private boolean pantallaCompleta = false;
    private GraphicsDevice gd;
    private JFrame frame;
    private JPanel panel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
   private Map<String, String> validUsers = new HashMap<>();
    private int initialX;
    private int initialY;

    public NuevaVentana () {
        // Configurar la ventana sin bordes ni barras de título
        setUndecorated(true);
     
        // Obtener el dispositivo gráfico principal (pantalla)
        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();

        // Obtener la resolución de la pantalla
        int screenWidth = gd.getDisplayMode().getWidth();
        int screenHeight = gd.getDisplayMode().getHeight();

        // Configurar el tamaño de la ventana para ocupar casi toda la pantalla
        int ventanaWidth = screenWidth - 500; // Restar 100 píxeles para dejar un pequeño margen
        int ventanaHeight = screenHeight - 270; // Restar 100 píxeles para dejar un pequeño margen
        setSize(ventanaWidth, ventanaHeight);

        // Configurar la ubicación para centrar la ventana
        setLocationRelativeTo(null);

        // Configurar la operación de cierre de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un panel para contener los componentes
        panel = new JPanel();
        panel.setLayout(null);
      // Establecer el fondo del panel en blanco
        panel.setBackground(Color.WHITE);

       

    

        // Agregar el panel a la ventana principal
        add(panel);
        
        // Crear una fuente personalizada
       


         // Agregar el JLabel exitTxt
         JLabel exitTxt = new JLabel();
         exitTxt.setFont(new Font("Roboto Light", Font.PLAIN, 24));
         exitTxt.setHorizontalAlignment(JLabel.CENTER);
         exitTxt.setText("X");
         exitTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
         exitTxt.setPreferredSize(new java.awt.Dimension(27, 27));

         // Ajustar la posición de exitTxt para que sea más visible
         exitTxt.setBounds(3, 5, 40, 40);

         // Asegurarse de que el color del texto sea visible en el fondo blanco
         exitTxt.setForeground(Color.BLACK); 

                panel.add(exitTxt);

       // Crear un borde de color gris para la ventana
        LineBorder bordeGris = new LineBorder(Color.GRAY,5);

        // Establecer el borde de la ventana
        panel.setBorder(bordeGris);

        // Hacer visible la ventana
        setVisible(true);
        
        

        JLabel imagenLabel = new JLabel();
        ImageIcon imagenIcon = new ImageIcon("C:/Users/sebas/OneDrive/D"
               + "ocumentos/NetBeansProjects/SimpleJavaLo"
               + "ginMD-main/src/com/images/desedit.png");
      imagenLabel.setIcon(imagenIcon);
      imagenLabel.setBounds(38, 12, imagenIcon.getIconWidth()+1, imagenIcon.getIconHeight());

      // Agregar el JLabel al panel
      panel.add(imagenLabel);

       
       panel.repaint();
    

        // Agrega un MouseListener al JLabel para detectar clics en la imagen
        imagenLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                toggleFullScreen();
            }
        });

      
          // Agregar eventos del mouse para el JLabel exitTxt
        exitTxt.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                exitTxt.setForeground(Color.RED);
                System.exit(0);
            }

            public void mouseEntered(MouseEvent evt) {
                // Lógica para el mouse cuando entra en el JLabel exitTxt
            }

            public void mouseExited(MouseEvent evt) {
                // Lógica para el mouse cuando sale del JLabel exitTxt
            }
        });
        

    

        // Agregar un MouseAdapter para permitir mover la ventana
        panel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                initialX = e.getX();
                initialY = e.getY();
            }
        });

        panel.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int newX = getX() + e.getX() - initialX;
                int newY = getY() + e.getY() - initialY;
                setLocation(newX, newY);
            }
        });
    }


    
    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);

       if (isValid(username, password)) {
        JOptionPane.showMessageDialog(frame, "Inicio de sesión exitoso.");

        // Cerrar la ventana actual
        dispose();

        // Crear y mostrar la nueva ventana
        NuevaVentana nuevaVentana = new NuevaVentana();
        nuevaVentana.setVisible(true);
    } else {
        JOptionPane.showMessageDialog(frame, "Nombre de usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
    }
        // Limpia los campos después de la verificación.
        usernameField.setText("");
        passwordField.setText("");
    }

    // Verifica las credenciales
    private boolean isValid(String username, String password) {
        // Verifica si el usuario y la contraseña coinciden en la base de datos simulada
        String storedPassword = validUsers.get(username);
        return storedPassword != null && storedPassword.equals(password);
    }
  
    
    
 private void toggleFullScreen() {
    if (pantallaCompleta) {
        // Salir del modo de pantalla completa
        setExtendedState(JFrame.NORMAL);
        pantallaCompleta = false;
    } else {
        // Minimizar la ventana
        setExtendedState(JFrame.ICONIFIED);
        pantallaCompleta = true;
    }
}
   
    
    
}



   
